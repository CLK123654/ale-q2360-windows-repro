CREATE TABLE public.scada_event_legacy (
  source_seq bigint,
  event_id text,
  site_code text,
  turbine_id text,
  event_time timestamptz,
  event_type text,
  severity text,
  power_kw numeric,
  payload jsonb
);
CREATE INDEX scada_event_legacy_time_idx ON public.scada_event_legacy(event_time);
