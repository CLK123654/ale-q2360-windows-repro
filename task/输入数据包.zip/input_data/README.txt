海上风电SCADA月度分区切换材料

scada_events.csv保存脱敏事件，partition_plan.csv给出月界和预期记录量，query_set.csv给出交接查询，legacy_schema.sql记录现有单表结构，change_window.txt说明本次切换范围。

所有时间按UTC解释。输入数据只用于演练，不连接生产环境。
